# progress.md — HazeGuard AI

> **Note (2026-10-11) — layout changed.** The project was reorganised into the
> Joomla-style MVC layout described in `README.md`. File paths mentioned below
> (`app/`, `frontend/`) refer to the **pre-refactor** layout: `app/bootstrap.php`
> is now `bootstrap.php`, `app/public/index.php` is now `index.php`,
> `app/src/*` is now `libraries/HazeGuard/*`, `app/api/auth/*` is now
> `components/com_hazeguard/Controller/AuthController.php`, and `frontend/` is
> now `templates/hazeguard/` + `media/com_hazeguard/`.

Single source of truth for the project plan and verified progress. Update before work, after milestones, after testing, on blockers, and at session end.

## 1. Project overview

HazeGuard AI — mobile-first web app: "Understand the air. Plan smarter. Breathe better." Air-quality checks around you, an interactive haze map, AI activity planning, and an AI assistant (BreatheBuddy) that cites real tool output. Built for a student hackathon with free-tier services and honest labelling of demo/estimate data.

## 2. Objectives and requirements

See `AGENTS.md` (stack, security, conventions) and the project brief. Summary: check local air quality with source/unit/timestamp; explore an interactive map; AI activity recommendations; AI Q&A; accounts + preferences; mobile-first with desktop layout; free services; real data where available with demo data clearly labelled; maintainable code.

## 3. Technology decisions

| Area | Decision | Reason |
|---|---|---|
| Frontend | HTML/CSS/vanilla JS, no framework | User mandate; hackathon-scale app |
| Backend | Plain PHP 8 (no framework), PDO, PHP sessions | User mandate (changed 2026-10-11 from Flask): PHP only; no Composer dependency |
| AI integration | Small Python Flask microservice on localhost, called by PHP over HTTP | User mandate: AI is the only Python part; LLM key lives only in the Python env |
| DB | MySQL + phpMyAdmin | User mandate (pairs naturally with PHP). **Dev runs XAMPP's MariaDB 10.4.32** (drop-in, InnoDB/utf8mb4); production targets MySQL 8 |
| Air data | Open-Meteo Air Quality API (first) | Free, coordinate-based; APIMS access unverified |
| Maps | Leaflet + OSM | Free; no Google Maps paid APIs |
| Charts | Hand-built SVG in Stage 1A, Chart.js in Stage 6 | No chart dependency needed for demo data |
| AI | Python Flask microservice with tool calling; PHP proxies; provider TBD in Stage 4 | Keys never in frontend, never in PHP; pricing needs documenting |
| Email | `Mailer` with pluggable drivers: `log` (dev default) and `brevo` (HTTP API) | User asked which provider is best; Brevo recommended (free 300/day, no card, works from PHP cURL so no Composer). Driver is an env choice, not a code change |
| Fonts | Self-hosted woff2 in `frontend/assets/fonts/`, system stack as fallback | No runtime third-party font dependency |
| Git | Installed (2.55.0) — repository not yet initialised | `git init` recommended before Stage 2 so `.env` protection and rollback are real |

## 4. Roadmap

| Stage | Scope | Priority |
|---|---|---|
| 0 | Repository inspection + documentation | Required — DONE |
| 1A | HTML/CSS/JS design prototype | Immediate — code complete |
| 1B | Authentication UI + backend integration | High — IN PROGRESS (register / verify / login / OTP done) |
| 2 | PHP backend + database foundation | High — foundation delivered early during Stage 1B |
| 3 | Air-quality data + Haze Radar | High |
| 4 | BreatheBuddy AI | High |
| 5 | AI Activity Planner | High |
| 6 | History, preferences, optional alerts | Medium |
| 7 | Security, QA, VPS deployment | Required before release |

**Execution rule:** Stage 1A must be complete and verified before any PHP/MySQL/real-auth work. Stage 1B+ builds on the existing prototype; no rebuilding the UI.

## 5. Task list, statuses, dependencies, acceptance criteria

Statuses: `NOT STARTED` · `IN PROGRESS` · `BLOCKED` · `COMPLETED` · `DESCOPED`

| ID | Task | Depends on | Acceptance criteria (abbreviated) | Status |
|---|---|---|---|---|
| T0.1 | Repository inspection | — | Existing state understood, nothing destructively changed | COMPLETED |
| T0.2 | AGENTS.md + progress.md created | T0.1 | Docs exist, cover required sections | COMPLETED |
| T0.3 | Roadmap, task IDs, architecture, commands recorded | T0.2 | Roadmap + initial task identified | COMPLETED |
| T1A.1 | Design system + app shell: tokens, five-item bottom nav, desktop sidebar, screen router | T0.3 | 5 items (Home/Radar/Planner/AI Chat/Profile), active state, keyboard/a11y, safe-area, no content hidden, desktop replaces bottom bar | COMPLETED (static-verified) |
| T1A.2 | Landing page (wordmark, hero, features, 3 preview sections, CTAs, footer) | T1A.1 | Accessible without login, demo content labelled, no `<YQ/>` | COMPLETED (static-verified) |
| T1A.3 | Auth screens: 3-method login, register+validation, OTP entry+countdown, verification result (ok/fail), forgot + reset | T1A.1 | All 3 methods switchable without layout loss; client validation works; no fake session/OTP-sent claims | COMPLETED (static-verified) |
| T1A.4 | Dashboard (greeting, AQI + PM cards, source/timestamp, radar + AI previews, history chart, quick actions, profile/logout) | T1A.1 | All elements present, demo values labelled, quick actions navigate | COMPLETED (static-verified) |
| T1A.5 | Haze Radar preview (map placeholder, search UI, use-my-location, legend, info panel, loading/denied/unavailable states) | T1A.1 | States present; not claimed interactive; source/timestamp shown | COMPLETED (static-verified) |
| T1A.6 | AI Activity Planner preview (activity/location/date/time/prefs → generate → recommendation + explanation + indoor alt + save) | T1A.1 | Demo recommendation labelled; save gives honest feedback | COMPLETED (static-verified) |
| T1A.7 | BreatheBuddy chat demo (header, bubbles, input, suggestions, typing indicator, error + empty states) | T1A.1 | JS demo replies work; labelled as demo, not a real model | COMPLETED (static-verified) |
| T1A.8 | Air Quality History (chart, period + metric selection, summary cards, source/timestamp, empty state) | T1A.1 | Chart renders, demo data labelled, controls work | COMPLETED (static-verified) |
| T1A.9 | Profile & settings (info, preferences, location placeholder, notifications, account, logout) | T1A.1 | Present, consistent, no persistence implied | COMPLETED (static-verified) |
| T1A.10 | Frontend interactions: router, toggles, validation, toasts, loading/empty states | T1A.2–T1A.9 | No critical console errors; interactions verified in browser | IN PROGRESS (wired + statically checked; live-browser check not performed) |
| T1A.11 | Responsive + accessibility verification (360/390/768/1024/1440, overflow, console, detector) | T1A.10 | No horizontal overflow, no overlap, checks recorded with real results | **DESCOPED (2026-10-11)** — user chose to verify manually; automated browser sweep not performed |
| T1A.12 | Design review + refinement pass (impeccable/apple-design guidance) | T1A.11 | Issues found are fixed; second confirmation round done | IN PROGRESS (3 detector rounds done, findings fixed/justified; live re-check not performed) |
| T1B.1 | Registration + server-side validation + email verification flow | Stage 1A | Acceptance tests §9.1 pass | **COMPLETED (2026-10-11)** — 20 checks pass (code-based verification; log mail driver) |
| T1B.2 | Login: email+password, username+password | T1B.1, T1B.6 | Invalid credentials rejected; sessions issued | **COMPLETED (2026-10-11)** — 9 checks pass |
| T1B.3 | Email OTP login (secure, hashed, 5-min, single-use, rate-limited) | T1B.1, T1B.6 | Expired/reused/brute-force OTP rejected; no code logging | **COMPLETED (2026-10-11)** — 9 checks pass |
| T1B.4 | Forgot/reset password (hashed single-use credential, rate limits) | T1B.1, T1B.6 | Reset works once; reuse fails; rate limits bound guessing | **COMPLETED (2026-10-12)** — 6-digit code on `email_otps` (`purpose='reset_password'`), not an emailed link; 5-min TTL, single-use, `OTP_MAX_ATTEMPTS` cap, `reset:email`/`reset:ip`/`resetverify:ip` limiters; see §13 |
| T1B.5 | Sessions, logout, CSRF, protected routes | T1B.2 | HTTP-only cookies, session regeneration, CSRF enforced, unauthenticated rejected | **IN PROGRESS — code complete, evidence incomplete.** Read 2026-10-12: every criterion is already implemented (`Session::start` sets `httponly`+`samesite`+`secure`; `Session::regenerate()` rotates id + CSRF on login *and* logout; `index.php:99-101` enforces CSRF on every POST/PUT/PATCH/DELETE before dispatch; `requireAuth()` 401s `GET /api/auth/me`). **What is missing is proof, not code** — see §10 and §14 |
| T1B.6 | MySQL schema (users, email_verification_tokens, email_otps, rate_limits) + phpMyAdmin import docs | Stage 1A | Schema imports cleanly; indexes/FKs/unique constraints present | **COMPLETED (2026-10-11)** — imports cleanly; 8 schema checks pass. *Least-privilege DB user blocked by a pre-existing MariaDB Aria fault — see §11.* `password_reset_tokens` was part of this and was **dropped 2026-10-12** when reset moved to OTP — see §7. |
| T1B.7 | Stage 1B acceptance test suite | T1B.1–T1B.6 | All §9.6 tests run and pass; critical security issues resolved | IN PROGRESS — `php tests/run.php` = **52/52 pass** for the built scope; reset + full-hardening tests pending T1B.4/T1B.5 |
| T2.1 | PHP app structure (app/public front controller, app/src), config/env loading, .env.example | T1B | `php -S` dev command documented; no hardcoded secrets | **COMPLETED (2026-10-11)** — delivered as the Stage 1B foundation: `app/public/index.php` front controller + router, `app/src/*`, `app/bootstrap.php`, `Config` (.env loader), `.env.example` |
| T2.2 | DB access helpers (PDO), API response convention, validation/error handling, logging | T2.1 | Conventions documented; secrets not logged | **COMPLETED (2026-10-11)** — `Db` (PDO, parameterised), `Response` (JSON envelope), `Validator`, `Request`, exception handler with `error_log`; convention documented in §8 |
| T2.3 | Backend foundation tests + documented dev/prod commands (php -S dev; Nginx+PHP-FPM prod) | T2.2 | Tests pass; commands reproducible | IN PROGRESS — `tests/run.php` passes and the dev command is documented; production Nginx/PHP-FPM config not yet written or tested |
| T3.1 | "Use my location" → PHP → Open-Meteo lookup with full error handling | T2.2 | Real reading with source/units/timestamps; all error states handled; missing ≠ 0 | NOT STARTED |
| T3.2 | Leaflet map: markers, popups, legend, search, selected-location panel, mobile controls | T3.1 | Map loads, markers use real data, source + timestamp visible | NOT STARTED |
| T3.3 | APIMS programmatic-access investigation documented | — | Verdict + evidence recorded before any official-data claims | NOT STARTED |
| T4.1 | BreatheBuddy: Flask AI microservice (ai-service/ai.py) + PHP proxy endpoint with tool calling | T2.2, T3.1 | ≥1 air-quality question answered via a real tool; LLM key only in Python env; AI service binds localhost | NOT STARTED |
| T4.2 | Tool set implemented + validated (incl. ownership checks, timeouts) | T4.1 | Args validated; private data owner-only; no invented readings | NOT STARTED |
| T4.3 | Chat frontend wired to backend | T4.2 | Real responses render safely; errors + stale/missing data handled | NOT STARTED |
| T5.1 | Planner: real data + AI recommendation with review-before-save | T3.1, T4.1 | Plan generated; source/timestamp stated; no future guarantees | NOT STARTED |
| T5.2 | Plan persistence in MySQL (list/edit/delete, owner-only) | T5.1, T1B.6 | Survives logout/login; cross-user access denied | NOT STARTED |
| T6.1 | Air-quality history with Chart.js from available records | T3.1 | Gaps visible as missing; demo data labelled if used | NOT STARTED |
| T6.2 | Preferences + saved locations persist | T1B.6 | Preferences survive relogin; validated | **PARTIAL (2026-10-12)** — activity chips, preferred location, change-password and delete-account are live and persisted in `user_preferences`; **notifications deliberately excluded** (nothing delivers them). 36 checks. Remaining: nothing on this task — see §13 |
| T6.3 | Optional alerts / in-app notifications | T6.2 | Only claimed as real-time if polling+delivery actually exist; descoping decision at Stage 6 start | NOT STARTED |
| T7.1 | Security checklist (§15) pass | Stages 1B–6 | Every checklist item verified and recorded | NOT STARTED |
| T7.2 | Full QA pass (flows, failures, isolation, responsive, production config) | T7.1 | Critical tests pass; failures recorded honestly | NOT STARTED |
| T7.3 | VPS deployment (Nginx + PHP-FPM, systemd for AI service, HTTPS, backups, smoke tests) | T7.2 | App live over HTTPS; restart-on-failure; secrets not committed | NOT STARTED |

**Applicable tasks: 38** (39 total − 1 descoped). **Descoped: 1** (T1A.11).

## 6. Feature acceptance criteria

Covered per-task in §5; full criteria live in the project brief sections (Stage 1A §8.17, 1B §9.6, Stages 3–7 acceptance lists). A task is `COMPLETED` only when its criteria are checked with recorded results.

## 7. Database design

**Implemented (T1B.6 — `database/schema.sql`).** All tables InnoDB / utf8mb4, timestamps stored in UTC, parameterised queries only.

- `users` — id, username UNIQUE, email UNIQUE, password_hash, email_verified_at NULL, status ENUM('pending','active','suspended') DEFAULT 'pending', created_at, updated_at.
- `email_verification_tokens` — id, user_id FK→users (CASCADE), token_hash CHAR(64) UNIQUE, expires_at, used_at, created_at. **Provisioned per brief §9.5 but not yet wired**: the Stage 1A UI verifies email with a 6-digit code (see `email_otps`), so the link-based flow is deferred.
- `email_otps` — id, user_id FK→users (CASCADE), **purpose ENUM('verify_email','login','reset_password')**, otp_hash CHAR(64), expires_at, used_at, attempt_count, created_at. *`purpose` is an addition to §9.5 so one table serves all three code flows.* `reset_password` was added on 2026-10-12 when password reset moved off emailed links.
- `rate_limits` — bucket VARCHAR(191) PK, hits, window_start. *Addition to §9.5*: fixed-window counters for OTP requests and login attempts.

**Dropped 2026-10-12 — `password_reset_tokens`.** Password reset originally emailed a link built from `APP_URL`, and this table held the hashed link tokens. The `APP_URL` coupling was the defect: a stale value made every link point at a dead port, and a `localhost` link cannot be opened from a phone. Reset now issues a 6-digit code on `email_otps` like the other two flows, so the table has no reader left and was dropped (`database/migrations/2026-10-12-reset-uses-otp.php`) along with `TokenModel::issueResetToken()/consumeResetToken()` and `Mailer::sendPasswordReset()`.

Indexes on token_hash / user_id / expires_at as applicable; FKs to `users`. Later stages add `activity_plans`, `user_preferences`, `saved_locations`, optional `alert_rules`.

**Dev/prod difference:** local dev runs XAMPP's **MariaDB 10.4.32**; production targets MySQL 8. The schema uses only features common to both (InnoDB, utf8mb4, ENUM, `IF()` in upserts, no MySQL-8-only syntax).

## 8. API contracts

Convention (**implemented**): JSON responses `{"ok": bool, "data": ..., "error": {"code": str, "message": str, "fields"?: {field: msg}}}`; meaningful HTTP status codes; state-changing routes are POST and require the `X-CSRF-Token` header; auth via session cookie.

| Endpoint | Method | Purpose | Status |
|---|---|---|---|
| /api/auth/session | GET | CSRF token + current user (client bootstrap) | **DONE** |
| /api/auth/me | GET | Current user; 401 when signed out (protected) | **DONE** |
| /api/auth/register | POST | Create pending account, email a verification code | **DONE** (T1B.1) |
| /api/auth/verify-email | POST | Activate account with a 6-digit code | **DONE** (T1B.1) |
| /api/auth/resend-verification | POST | Re-send verification code (rate-limited) | **DONE** (T1B.1) |
| /api/auth/login | POST | Password login (email **or** username) | **DONE** (T1B.2) |
| /api/auth/login/otp/request | POST | Request an email sign-in code (rate-limited) | **DONE** (T1B.3) |
| /api/auth/login/otp/verify | POST | Verify the sign-in code, issue a session | **DONE** (T1B.3) |
| /api/auth/logout | POST | Destroy session, clear cookie | **DONE** |
| /api/auth/password/forgot, /api/auth/password/reset | POST | Reset flow (emailed 6-digit code) | **DONE** (T1B.4) |
| /api/air/current?lat&lon | GET | Open-Meteo lookup + BigDataCloud reverse geocode | **DONE** (T3.1 — done early; see §13) |
| /api/air-quality?lat&lon | GET | Superseded by `/api/air/current` | REPLACED |
| /api/air-quality/history?lat&lon&period | GET | Available historical records | NOT STARTED (T6.1) |
| /api/chat | POST | BreatheBuddy turn with tool calls | NOT STARTED (T4.1) |
| /api/plans, /api/plans/<id> | GET/POST/PATCH/DELETE | Activity plans, owner-only | NOT STARTED (T5.2) |
| /api/profile/preferences | GET | Activity chips + saved location (protected) | **DONE** (T6.2) |
| /api/profile/activities | PUT | Replace chosen activities | **DONE** (T6.2) |
| /api/profile/location | PUT | Save or clear the preferred location; **the AQI reading follows it** | **DONE** (T6.2) |
| /api/profile/password | POST | Change the signed-in account's password | **DONE** (T6.2) |
| /api/profile | DELETE | Delete the signed-in account and its data | **DONE** (T6.2) |
| /api/places/search?q | GET | Candidate places for a typed city name | **DONE** (T6.2) |
| /api/places/reverse?lat&lon | GET | Name of a detected position | **DONE** (T6.2) |

## 9. Completed work

- **T0.1 (2026-10-11):** Directory was empty; no Git installed (`git` not recognised); Node v24.21.0 + npm 11.19.0 available, Python **not** installed (stack later changed: PHP now blocks Stage 1B, Python only blocks Stage 4 — see §11). Browser automation tools available (navigate/evaluate/screenshot/console/Lighthouse); no viewport-resize tool → responsive checks will use an iframe harness.
- **T0.2 (2026-10-11):** `AGENTS.md`, `progress.md`, `PRODUCT.md` (Impeccable product record) created.
- **T0.3 (2026-10-11):** Roadmap, 39 task IDs, dependencies, acceptance criteria, DB/API plans recorded above.
- **T1A.1–T1A.9 (2026-10-11):** Stage 1A prototype built: `frontend/index.html` (all 13 screens + icon sprite + brand symbol + splash), `frontend/css/style.css` (design tokens, all screen styles, breakpoints at 400/600/768/1024/1440, reduced-motion/contrast/transparency support), `frontend/js/app.js` (hash router, validation, OTP flows, radar states, planner, canned chat, hand-built SVG charts). Verified statically (see §10); browser interaction checks not performed (user chose to proceed without a browser — see §11).
- **T1A.10 (partial):** All interactions wired and statically checked; "no critical console errors in a live browser" remains unverified.
- **T1A.12 (partial):** Impeccable detector run 3× on the frontend; all mechanical findings fixed (contrast, gradient layering, em-dash copy, font sizes, glow shadows, splash contrast). Remaining 3 findings recorded as justified exceptions (§10). Second confirmation round done for CSS (0 findings); HTML/JS re-check pending after next change.
- **Splash (2026-10-11):** Initial-load splash added: light background, brand logo in a rotating emerald→cyan conic ring, dot indicator, 400 ms fade-out on `window load` (immediate if already loaded), removed from the DOM after hiding, `role="status"` + reduced-motion safe. Reusable `#brand-mark` SVG symbol now used by splash, landing, auth screens, and sidebar (was 8 inline copies).
- **T1B.6 (2026-10-11):** `database/schema.sql` (5 tables, indexes, FKs, unique constraints) + `database/bootstrap.sql` (database + least-privilege user template) + `.env.example` + `.gitignore`. The `hazeguard` database was created and the schema imported into the running MariaDB; verified with `SHOW TABLES` and 8 automated schema checks.
- **T1B.1 (2026-10-11):** Registration + email verification + resend. `app/src/Validator.php`, `app/src/Services/TokenService.php` (hashed 6-digit codes, 5-min TTL, single-use, attempt cap), `app/src/Mailer.php` (log + Brevo drivers), `app/api/auth/{register,verify-email,resend-verification}.php`.
- **T1B.2 (2026-10-11):** Password login by email or username, generic failure messages (no enumeration), timing-equalised dummy hash, unverified/suspended handling, session issuance with id regeneration, `GET /api/auth/me`, `POST /api/auth/logout`.
- **T1B.3 (2026-10-11):** Email-OTP login: rate-limited request, hashed code, single-use verify, attempt cap, session issuance.
- **T2.1 + T2.2 (2026-10-11, delivered as the Stage 1B foundation):** `app/bootstrap.php` (autoloader + config + error handling), `Config` (.env loader), `Db` (PDO, parameterised), `Response` (JSON envelope), `Request`, `Session`, `Csrf`, `RateLimiter` (fixed-window), `app/public/index.php` (front controller + dev router), `.env.example`.
- **Frontend wiring (2026-10-11):** `frontend/js/api.js` (fetch wrapper: CSRF sync, envelope parsing, typed errors) and `frontend/js/app.js` rewired so the register/login/OTP handlers call the real API, surface inline field errors, and guard app screens behind a session. **All Stage 1A markup preserved** (only `app.js` behaviour changed + one `<script>` tag added).

## 10. Tests performed and actual results

- `node --check frontend/js/app.js` — **PASS**; `node --check frontend/js/api.js` — **PASS**.
- `node tests/static-check.cjs` (2026-10-11, after Stage 1B frontend wiring) — **ALL 25 CHECKS PASS** (13 screens, no duplicate ids, icon refs resolve, **70** JS-referenced ids exist, nav targets valid, router table matches, bottom nav exactly 5 items, CSS braces balanced, all CSS variables declared, no `console.*`, no emoji, ≥8 demo badges).
- `php -l` on every file under `app/` — **all clean**.
- **`php tests/run.php` (2026-10-11) — ALL 52 ACCEPTANCE CHECKS PASS**, against an isolated `hazeguard_test` database:
  - **T1B.6 schema (8):** 5 tables exist; UNIQUE indexes on username and email; FK from `email_otps` to `users`.
  - **T1B.1 register/verify (20):** user created pending; password hashed and `password_verify` OK; verification code emailed; OTP stored as sha256 (not plaintext); duplicate username/email rejected; 3 field errors for invalid input; wrong code rejected; correct code activates; code marked used; expired code rejected; resend allowed 3× then rate-limited; resend for an unknown email still reports success (no enumeration).
  - **T1B.2 password login (9):** unverified blocked; login by email and by username both succeed; session established and correct; wrong password rejected; unknown account returns the **identical** generic message; suspended blocked; logout clears the session.
  - **T1B.3 OTP login (9):** unknown email reports success (no enumeration); request + verify works; session established; wrong OTP rejected; OTP single-use; code burned after 5 wrong attempts; requests allowed 3× then rate-limited.
  - **CSRF + rate limiter (6):** token stable per session; correct token accepted; wrong/empty token rejected; limiter blocks past the limit; clear resets the bucket.
- **HTTP smoke tests (2026-10-11)** against `php -S localhost:8000 -t frontend app/public/index.php`: session bootstrap returns a CSRF token; static assets (html/css/js) served; unknown API route → 404 JSON; POST without CSRF → 403 `csrf_invalid`; full register→verify→login→me→logout cycle works; **source files (`.env`, `app/src/*.php`, `database/schema.sql`) return 404** — the `frontend/` docroot keeps them private.
- Contrast check (2026-10-11, light-theme refactor, computed WCAG ratios) — **ALL 17 PAIRS PASS AA (≥4.5:1)**: text 15.9:1 on `--bg`, 17.2:1 on surface; text-2 8.2:1; text-3 5.2:1 (4.7:1 on surface-2); accent links 5.5:1 / 5.4:1; danger 6.5:1; AQI ink variants 4.9–6.5:1; accent-ink on primary gradient 9.8:1 / 10.5:1; prefers-contrast text-3 6.9:1.
- Impeccable detector (2026-10-11, final round on index.html + style.css + app.js) — 3 findings, all recorded as justified exceptions:
  1. `pulsing-dot` on `.splash__dots` — dots only exist while the page is genuinely loading; they are removed with the splash on load.
  2. `pulsing-dot` on `.typing i` — indicator only exists while a reply is pending; honest state signal.
  3. `repeating-stripes-gradient` — map/mini-map placeholder graticule, replaced by real Leaflet tiles in Stage 3.
  All earlier mechanical findings (body gradient layering, auth icon tile, font sizes <11px, glow shadows, em-dash copy, splash 2.3:1 contrast) were fixed; style.css re-check = 0 findings.
- Impeccable detector (2026-10-11, after light-theme refactor, index.html + style.css) — **same 3 justified exceptions** as above, no new findings.
- `php tests/run.php` (2026-10-12) — **ALL 217 ACCEPTANCE CHECKS PASS**, exit 0. Suites: schema, register/verify, password login, OTP login, **password reset**, mail drivers + Brevo key resolution + failure handling, CSRF, rate limiter, encrypted credentials, admin panels, air quality (bands, provenance, cache/stale, coordinate validation), and the `Http` IPv4 pinning rule.
- `node tests/static-check.cjs` (2026-10-12) — **ALL 52 STATIC CHECKS PASS**, exit 0.
- **One real defect found and fixed this pass:** `static-check.cjs` asserted `id="reset-invalid"` on the reset screen, but that element no longer exists in the markup — `showResetState()` (`app.js:522-528`) documents *why* it was removed: the "request a code first" gate made a code that had genuinely arrived read as a failed verification whenever the mail was opened on another device or a second tab. The check was the stale artifact, so it was rewritten to assert the design that replaced it (a `#reset-email` field is the source of truth, `pendingResetEmail` only pre-fills and never overwrites, no `reset-invalid` node). **No product code was changed to make a test pass.**
- **T1B.5 evidence gap (found by reading the code on 2026-10-12, not by a failing test).** Every acceptance criterion for T1B.5 is implemented, but the suite never asserts any of them: `grep -i 'requireAuth|cookie_params|samesite|httponly|regenerate_id|X-CSRF|unauthenticated' tests/run.php` returns **nothing**. The CSRF group tests `Csrf::token()`/`validate()` in isolation and never proves the router calls `Csrf::requireValid()`; no test proves `requireAuth()` returns 401, that the cookie carries `HttpOnly`/`SameSite`, or that `login()` rotates the session id. **A criterion with no assertion is an unverified claim, so T1B.5 stays IN PROGRESS.** Closing it = add those checks to `tests/run.php`; no production code should change unless one of them fails.
- **T6.2 profile preferences (2026-10-12)** — `php tests/run.php` → **256/256 PASS**, exit 0; `node tests/static-check.cjs` → **62/62 PASS**, exit 0. 36 new backend checks cover the save/replace/clear semantics, the slug allowlist, the per-account isolation (one account cannot read or write another's row), the password rules, the cascade on delete, and that **no notification column exists at all**.
- **Live HTTP smoke test of the profile flow (2026-10-12)**, against `php -S localhost:8124 index.php` with `MAIL_DRIVER=log`: register → activate → login → save activities → save location → read back → clear location → change password → old password rejected → delete account → session gone and `/api/profile/*` then 401. CSRF without a token = 403, signed-out = 401. **Three real bugs were found and fixed this way, all of which the unit suite had passed:**
  1. **Route keys were padded** (`'GET    /api/profile/preferences'`). Lookup is `$method . ' ' . $path`, so every profile route 404'd. Invisible to unit tests — they call the model, not the router.
  2. **`ProfileController::preferences()` handed `read()`'s bare array to the view.** `JsonView::render()` finds no `ok` key and answers `data: null`, so the profile screen silently showed defaults. Fixed with `ProfileModel::result()`.
  3. **The strength rule was applied to the current password.** A mistyped short password was told *"Use at least 8 characters"* instead of *"Not correct"*, and an account whose existing password predates the 8-character rule could not change it at all. Only `Validator::required` applies to the current password now.
- **Schema note:** `database/schema.sql` gained `user_preferences` and `users.password_changed_at`. **The live dev database needed the migration** — `database/migrations/2026-10-12-user-preferences.php` (idempotent, re-verified) — because `tests/run.php` builds its own database from `schema.sql` and therefore passed while the running app 500'd. Worth remembering: **a green suite does not prove the dev database is migrated.**
- **Preferred location drives the AQI (2026-10-12, product-owner request).** Verified live over HTTP against the real Open-Meteo API: no saved location → *Kuala Lumpur, AQI 76, source `default`*; save Johor Bahru → **place Johor Bahru, AQI 155, source `saved`**; switch to Kuala Lumpur → **place Kuala Lumpur, AQI 76**; switch back → **Johor Bahru, 155**. An explicit coordinate (the Haze Radar's own search) still wins and still reports `device`.
  - **The city name is resolved server-side, from the coordinates being saved**, and the client's `name` field is no longer read or accepted. The client's copy may be a fallback string, and the saved location labels every future reading — a wrong name there would mislabel the air. Same geocoder the reading already uses.
  - **Coordinates are rounded to 4dp (~11 m)** before storage, so the row does not imply a precision neither the model grid nor the geocoder has.
  - **Three sources, each described differently** in `provenance`: `device` → "For your location"; `saved` → "For your saved location — <place>"; `default` → "For <city> — your location was not shared". A saved place is never dressed up as the phone's position.
  - **The saved location outranks the device position**, deliberately: someone travelling from Johor Bahru to Kuala Lumpur sets the preference once and then reads their chosen city. `airquality.js` stops sending the device coordinate once a location is saved (`usePreferredLocation()`), and refreshes immediately on save rather than waiting out the hour — otherwise the instrument would show the previous city's AQI under a live badge.
  - `AirModel::pointFor()` was extracted so the choice of point is testable without a network call; 12 new backend checks and 6 new static checks cover it (268 backend, 68 frontend).
- **Profile location UX corrected (2026-10-12, product-owner correction).** The first version made "Change" re-run device geolocation, which was wrong twice over. Corrected to: **opening Profile auto-detects and names the current city**, and **Change searches for another city** (the owner had asked for exactly this; the earlier build had "Change" silently overwrite the stored preference with wherever the phone was).
  - **The two locations are now deliberately separate.** `storedLocation` is the city the account chose and is what the AQI reads; `currentLocation` is what the browser reported on this visit and is **never persisted**. Detection returns early when a preference exists, so it can never paint over the choice — otherwise the screen and the instrument would disagree about which city they are in.
  - **Two new routes, `PlacesModel` + `PlacesController`.** Forward geocoding needed a new provider: the keyless BigDataCloud *reverse* endpoint returns **403 on its search path** (verified). Forward is **Photon** (photon.komoot.io, keyless, OSM data); reverse reuses the BigDataCloud call `AirModel` already makes. Both are public and rate-limited (`places:ip`, 30/5min) so this cannot become an open relay against a third party's quota.
  - **Verified live**: search "Kuala Lumpur" → KL 3.1517,101.6942 · "Penang" → Penang Island, Penang Hill (Penango, Italy also returned) · "Kota Kinabalu" → 5.978,116.073. Pick → server resolves the name → AQI switches: **Kuala Lumpur 77 → Kota Kinabalu 62 → Johor Bahru 153**, each `source=saved`. Reverse geocode: JB→"Johor Bahru", KL→"Kuala Lumpur", bad input→null.
  - **Search UX details**: 300 ms debounce (a 9-character name costs one request, not nine), a sequence guard so a slow "Kuala" cannot overwrite "Kuala Lumpur", near-duplicate results collapsed (Photon returns the same city at slightly different points), rows built in JS so no template edit is needed to add one, and full keyboard support (ArrowUp/Down to move, Enter to pick, `role="combobox"`/`listbox`).
  - 10 new backend checks and 7 new static checks (278 backend, 76 frontend).
- **Relocate button added (2026-10-12, product-owner request).** A target/crosshair icon button (`#i-locate`, already in the sprite) sits beside **Change**. It closes a real gap the previous split had opened: detection on entry never saves and **Change** only searches for other cities, so there was **no way to move a saved city back to where you actually are**. Pressing relocate detects *and* saves, then re-reads the air immediately.
  - Verified live round-trip: nothing saved → Kuala Lumpur 77 (`default`); relocate → **Johor Bahru 155** (`saved`); search+pick KL → **Kuala Lumpur 77**; relocate again → **Johor Bahru 155**.
  - Disabled while in flight, so a second tap cannot fire two geolocation requests and two racing saves.
  - A denial gets its own sentence ("your browser would not share a location, so nothing was changed") and leaves the saved city exactly as it was. `GEO_DENIED` is a named constant because `navigator.geolocation` rejects with a numeric `code`, not a string — an earlier draft compared against the string `'PERMISSION_DENIED'`, which could never have matched.
  - **Superseded by Session 12 below**, which removed the gap this button existed to close: the load itself now writes the device's position, so the button's remaining purpose is *someone who moved since the page opened*, which is why it forces a fresh detection.
- **Session 12 — the location model replaced (2026-10-12).** The owner restated the rules and they differ from what Session 9/10 built, so the *detected-vs-preferred* split was **deleted**, not extended. One location, stored: every load saves the device's coordinates; changing it re-saves; signed in reads the saved row, signed out reads the device. Details and the boot-order defect that caused the reported "auto reload, then it says Not set" are in §16, Session 12.
  - **Live HTTP verification, 15/15** (throwaway `storage/smoke.ps1`, real server, real register/verify/login, real Open-Meteo). Asserted: signed in with nothing saved → `default`; saving Johor Bahru → server-resolved name **and** the reading becomes `saved`; switching to Kuala Lumpur → the reading follows; the two cities genuinely read differently; an explicit coordinate still answers `device` and never borrows the saved name; signed out → `device` with a coordinate and `default` without; the saved row survives the whole session. `.env` was flipped to `MAIL_DRIVER=log` for the run and restored afterwards.
  - **`Config::get()` gives `.env` priority over the process environment**, so exporting `MAIL_DRIVER` has no effect — the value must be changed *in `.env`*. Brevo's IP allow-list rejects this machine, and `register()` returns 502 when the welcome mail fails, which is how this was found.
  - **Still not covered by any test: the client-side half of all three rules** — there is no browser attached, so `saveDeviceLocation()`, `beginSession()`, `relocateToCurrentPosition()` and the `refreshSeq` guard have been reasoned about and static-checked but never run.
- **Two owner-reported bugs on a real page load (2026-10-12), both fixed:**
  1. **`Locating…` and `Searching…` rendered with three junk glyphs after the word.** This was **file corruption I had introduced earlier in this same session**, not a browser or server problem. A PowerShell `Get-Content -Raw` → `[IO.File]::WriteAllText` round-trip decodes bytes as Windows-1252 and writes them back as UTF-8, so every non-ASCII character silently became two or three — an ellipsis (U+2026) became a-circumflex + euro + broken bar. It hit exactly the two files I had round-tripped — `app.js` and `ProfileModel.php` — and nothing else, which is what identified it. **The page charset was always correct** (`Content-Type: text/html; charset=UTF-8` plus `<meta charset="UTF-8">`), which is why the search pointed at the files rather than the server. The file stayed *valid* UTF-8 and still parsed, so **no existing test noticed** — repaired with `tests/encoding-check.php` (`--fix` reverses it run by run), which is now part of the documented commands. **Lesson: do not use PowerShell to rewrite UTF-8 source here; use the Edit tool.**
  2. **The location row sat on "Locating…" forever after a refresh, and relocate reported no location.** Two separate causes. (a) **The template shipped `Locating…` as the row's initial markup**, so any detection path that did not complete — including `if (!window.HazeAir) return` — left it waiting with no explanation. The markup now ships `Not set`, and *only* a detection that has actually started may say `Locating…`; every exit path sets a definite value. (b) **Two overlapping `getCurrentPosition` calls**: `airquality.js` boots with `refresh()` and the profile screen independently called `locate()`, and two concurrent calls fight over the permission prompt / GPS wake, so the second can time out while the first succeeded. `locate()` now **shares one in-flight promise** and releases it on settle — including on denial, so one refusal cannot wedge the page. Verified by `tests/locate-check.cjs`, which lifts the real function out of the source and runs it against a stub navigator: 3 concurrent callers → **1** request, all get the same answer, a later call is fresh, and **a denial releases the request too**.
- **Not performed:** browser verification (screenshots, console, interaction, responsive harness at 360/390/768/1024/1440). **DESCOPED by user on 2026-10-11 — the user will verify manually.** `tests/responsive.html` + `tests/serve.cjs` (port 8123) remain available for it.

## 11. Known bugs and blockers

- **MariaDB Aria storage-engine fault (blocks the least-privilege DB user).** XAMPP's MariaDB had a **pre-existing** corruption: the very first `GRANT` failed with `error 176 "Read page with wrong checksum"` from the Aria engine. `mysql.db` was repaired (5 already-corrupt rows were lost), but Aria writes then began failing with `error 122` / `error 1 "Operation not permitted"`, so `CREATE USER` / `GRANT` cannot complete, and `mysqld` memory grew from ~50 MB to ~1 GB while probing.
  - **Impact:** the app itself is unaffected — every `hazeguard` table is InnoDB and writes correctly.
  - **Workaround in place:** `.env` connects as `root` (no password) for **local dev only**. This is a documented deviation from the least-privilege requirement, which still applies to production.
  - **Fix:** restart XAMPP's MySQL (Control Panel → MySQL → Stop → Start), then run `database/bootstrap.sql` (replace `CHANGE_ME_STRONG_PASSWORD`) and switch `.env` to `DB_USER=hazeguard_app`.
- **PHP not installed** — *resolved*: XAMPP provides PHP 8.2.12 with all required extensions (pdo, pdo_mysql, mysqli, mbstring, openssl, curl, json, session, hash, filter).
- **Python not installed** — *resolved*: Python 3.13.14 is available (only needed from Stage 4).
- **Git not installed** — *resolved*: Git 2.55.0 is available. Repository **not yet initialised**; `git init` recommended before Stage 2.
- No blockers for Stage 1B development itself.

## 12. Technical decisions and reasons

See §3. Additional: prototype is a single-page screen router (`frontend/js/app.js`) so bottom-nav switching needs no page reloads; auth screens render outside the app shell (no bottom nav); demo interactions are in-memory only and never create a fake authenticated session.
- **2026-10-11 — Backend stack change (user-requested):** backend changed from Python/Flask to **plain PHP 8 (no framework)**; the **AI integration alone stays Python** as a small Flask microservice called by PHP over HTTP on localhost. Reason: user correction ("backend should use php, only ai integration use python"). Consequences recorded: `app/` now planned as PHP (public/ front controller, src/, api/), new `ai-service/` directory for the Python piece, LLM key confined to the Python env, deploy target Nginx + PHP-FPM + systemd (not WSGI), backend tests via `php tests/run.php` (pytest only for the AI service), blockers updated (PHP blocks Stage 1B, Python only blocks Stage 4). `@php-domain-best-practices` and `@application-layer` skills now apply; framework-integration skills do not.
- **2026-10-11 — Full light theme (user-requested):** design foundation changed from deep green-black to light (`--bg: #f4f7f5`, white surfaces). Reason: user asked to change the whole website to light theme. Structure kept: accent/AQI tokens re-tuned for AA on white (text-safe `--accent: #047857`, `--accent-2: #0e7490`, new `--aqi-N-ink` text variants + `--grad`/`--grad-hover` for bright filled controls with dark ink labels); vivid AQI colors kept only for non-text uses (band segments, dots, pins). Glass bars/toasts/map overlays flipped to white translucency; tinted light shadows; prefers-reduced-transparency and prefers-contrast blocks retuned; favicon updated to emerald tile.
- **2026-10-11 — Dev server is PHP's built-in server, not Apache.** `php -S localhost:8000 -t frontend app/public/index.php`; `/api/*` routes to the front controller, everything else is served statically from `frontend/`. Chosen because it is simpler, keeps source files and `.env` out of the docroot (verified: they 404), and is closer to the PHP-FPM model used in production. phpMyAdmin remains reachable through XAMPP's Apache on :80.
- **2026-10-11 — Email verification uses a 6-digit code, not a link.** The Stage 1A UI already renders a 6-digit code-entry screen, so `email_otps` (with a `purpose` column) serves both verification and OTP login; `email_verification_tokens` is provisioned for a future link flow.
- **2026-10-11 — Registration reveals "username/email already taken".** Deliberate trade-off: without it a returning user cannot tell why sign-up failed. Login, OTP requests and resend all use generic messages so they cannot be used to enumerate accounts (verified by test).

## 13. Current stage

**Stage 1B — nearly complete.** Register, email verification, password login, email-OTP login and **password reset** are implemented, wired into the frontend, and verified by **217 backend acceptance checks + 52 frontend static checks, all passing**.

Work delivered since §9 was last written (2026-10-12), not yet reflected above:
- **T3.1 (air quality) is effectively done, ahead of its stage.** `AirController`/`AirModel` + `media/…/js/airquality.js` serve a **real** Open-Meteo reading with an hourly re-read, BigDataCloud reverse geocoding for the city label, a 4-state model (live / stale / unavailable / no-JS) that never shows a stand-in number, and browser geolocation on request. ~35 of the 217 checks cover it.
- **Administrator side built** (`administrator/`): dashboard + Credentials / Create User / Create Usergroup CRUD panels, entity-driven so a panel needs no new controller, with encrypted credentials (AES-256-GCM) and FK-aware deletes.
- **Layout reorganised** into the Joomla-style MVC tree (§ note at the top); `Mvc/BaseController`, `HtmlView`, `JsonView` added.
- **T1B.4 completed** (above).

**T1B.5 remains the only unfinished Stage 1B item** — and its one real gap is now the whole task: a password reset does not invalidate sessions already open elsewhere, since PHP sessions live in files. Closing it means a `password_changed_at` column checked in `GET /api/auth/session` (one query per page load, not per request).

**T1B.4 — COMPLETED (2026-10-12), in two passes.** First built end to end on the `password_reset_tokens` table with an emailed link. Then reworked: the link depended on `APP_URL`, so a stale value pointed every reset email at a dead port, and the link was unopenable when the mail was read on a phone. Reset now issues a 6-digit code on `email_otps` (`purpose='reset_password'`, 5-minute TTL, `OTP_MAX_ATTEMPTS` cap, `resetverify:ip` limiter), the link path and its table are gone, and `APP_URL` no longer affects the flow. 34 checks cover it.

## 14. Exact next task

**T1B.5 — and the job is to write the tests, not the code.** Reading the source on 2026-10-12 confirmed all four criteria are already met in production code (`libraries/HazeGuard/Session.php:24-30` cookie flags, `:35-40` regeneration, `index.php:99-101` CSRF on every state-changing method, `AuthController::me()` → `requireAuth()`). The suite asserts none of them (§10). So:

1. Add to `tests/run.php`: the cookie carries `httponly` and `samesite`; `Session::login()` changes the session id; `Csrf::requireValid()` accepts the real token and rejects wrong/empty — i.e. prove the router path, not just the helper; `requireAuth()` yields 401 when signed out; `logout()` kills the id.
2. Run it. **Only touch production code if one of these fails** — the expectation is that none will.

**Already closed during T6.2:** the password-change session-invalidation gap that used to be listed here. `users.password_changed_at` is now stamped by both the reset and the profile change-password path, and `AuthController::sessionOutlivedPasswordChange()` ends any session older than it. Migration `database/migrations/2026-10-12-user-preferences.php`.

**Next after that:** T5.1/T5.2 (planner + persistence) or T3.2 (map) — whichever the product owner prefers. T3.2 is still blocked on the map-provider decision flagged in `README.md` (Leaflet + OSM is not a permitted source; the compliant providers have no free overseas tier).

**T1B.5 — and the job is to write the tests, not the code.** Reading the source on 2026-10-12 confirmed all four criteria are already met in production code (`libraries/HazeGuard/Session.php:24-30` cookie flags, `:35-40` regeneration, `index.php:99-101` CSRF on every state-changing method, `AuthController::me()` → `requireAuth()`). The suite asserts none of them (§10). So:

1. Add to `tests/run.php`: the cookie carries `httponly` and `samesite`; `Session::login()` changes the session id; `Csrf::requireValid()` accepts the real token and rejects wrong/empty — i.e. prove the router path, not just the helper; `requireAuth()` yields 401 when signed out; `logout()` kills the id.
2. Run it. **Only touch production code if one of these fails** — the expectation is that none will.
3. Then, separately and *only if wanted*, the one genuine behaviour gap: a password reset does not invalidate sessions open elsewhere (no `password_changed_at` column exists — confirmed absent from `database/schema.sql`). This is an enhancement beyond T1B.5's stated criteria, and the reset screen already tells the user honestly that it does not happen.

**Deliberately not next:** the profile screen's Change-password / Delete-account buttons. Verified 2026-10-12: they carry `data-action="demo-only"` (`templates/hazeguard/index.php:961,965`) and `app.js:1002` toasts *"Prototype — this control is not wired up yet."* That is honest labelling, not a bug — and profile/preferences are **T6.2**, not T1B.5.

**Housekeeping (do these before Stage 2):** add §5 task IDs for the air-quality work (T3.1), the administrator panels and encrypted credentials, which are built and tested but unlisted; restart XAMPP MySQL to clear the Aria fault and create `hazeguard_app` (§11); `git init` (Git 2.55.0 is installed but `git` is not on PATH in this shell — it is not usable from here as configured).

**Before Stage 2:** restart XAMPP MySQL to clear the Aria fault, create the `hazeguard_app` user, switch `.env` off `root`, and `git init`.

**Dev commands:**
```
php -S localhost:8000 index.php                         # dev server (site + JSON API)
php tests/run.php                                        # 278 backend acceptance checks
node tests/static-check.cjs                              # 93 frontend static checks
node tests/locate-check.cjs                              # geolocation promise sharing
php tests/encoding-check.php                             # mojibake scan (see §10)
node tests/serve.cjs 8123                                # static server for the responsive harness
```

**On Windows, `php` is not on PATH in this shell.** Use `C:\xampp\php\php.exe` explicitly (e.g. `& C:\xampp\php\php.exe tests/run.php`). **Git 2.55.0 is installed but likewise not on PATH here**, so `git init` cannot be run from this shell as configured.

## 15. Overall verified progress

**20/38 applicable tasks COMPLETED = 53%** — Stage 0: 3/3; Stage 1A: 9/12 (T1A.10/T1A.12 not fully verifiable without a browser; T1A.11 descoped); Stage 1B: **5/7** (T1B.1/T1B.2/T1B.3/T1B.4/T1B.6 done; T1B.5 remaining; T1B.7 partial); Stage 2: 2/3 (T2.1/T2.2 delivered early as the Stage 1B foundation; T2.3 partial); **Stage 6: T6.2 now delivered** (see the note below).

**Not counted in the 47→50% figure**, because §5 has no task ID for them yet — they are real delivered work that the task table does not yet describe: **T3.1 air quality** (`/api/air/current`, done early and verified by ~35 checks), the **administrator panels**, and **encrypted credentials**. §5 should gain IDs for these before Stage 7, since the percentage is otherwise understating the project. Descoped: 1 (T1A.11). Never inflated.

## 16. Change log

- **2026-10-11 — Session 1:** Stage 0 complete (inspection, docs, roadmap). Visual direction chosen with user: **deep green-black foundation, emerald/cyan accents**. Stage 1A started.
- **2026-10-11 — Session 2:** Stage 1A prototype built (all 13 screens, router, validations, demo interactions, SVG charts, responsive harness, static-check suite). Detector findings fixed; em-dash copy pass. User asked for an initial-load splash: added light Apple-inspired splash (logo + rotating emerald→cyan ring + dots, fade on real load, removed after hiding, reduced-motion safe, never shown during in-app navigation); extracted reusable `#brand-mark` SVG symbol replacing 8 inline brand copies; fixed splash wordmark contrast (#047857, 4.5:1+). Static checks all pass after changes. Browser verification still not performed (user choice). Bonus: ponytail-review found confirm-password validation was dead code (`reg-confirm`/`reset-confirm` had no validator entry so mismatch was never caught) — fixed in `validateField`; runtime behaviour pending browser verification.
- **2026-10-11 — Session 3:** Full light-theme refactor at user request (was deep green-black). Rewrote `:root` tokens, flipped all glass/translucent surfaces to white, added `--aqi-N-ink` text variants + `--grad` tokens, retuned reduced-transparency/contrast blocks, fixed favicon + `location-aqi` inline color to ink variants. Verified: static-check 25/25 pass, contrast script 17/17 pairs pass AA, detector = same 3 justified exceptions (no new findings). Live-browser check still pending (T1A.11).
- **2026-10-11 — Session 4:** Backend stack corrected per user: **PHP 8 plain (no framework)** for the backend, **Python Flask microservice only for AI integration** (PHP → HTTP localhost → ai-service; LLM key only in Python env). Updated AGENTS.md (stack, directory, conventions, security, testing, skills) and progress.md §3/§4/§5 (T1B/T2/T3/T4/T7.3 reworded; T1B.1–T1B.6 reset to NOT STARTED — no backend code exists yet, earlier "IN PROGRESS" reflected approval only) and §11 blockers (PHP blocks Stage 1B; Python blocks only Stage 4 — `python` on this machine is a Store alias stub, not installed).
- **2026-10-12 — Session 6:** Audited the repo against this file and found `progress.md` badly out of date — the code had moved on by an entire subsystem. Actions taken: (1) **Fixed a failing static check.** `static-check.cjs` required `id="reset-invalid"` on the reset screen, which no longer exists; `app.js:522-528` documents that the gate was deliberately removed because it made a legitimately-arrived code read as a failed verification on a second device. The *check* was stale, not the code, so it was rewritten to assert the replacement design (address field as source of truth, `pendingResetEmail` pre-fills without overwriting, no `reset-invalid` node). No product code was altered to make a test pass. (2) **Reconciled this file** — T1B.4 and the air-quality endpoint marked done, Stage 1B at 5/7, §10 rewritten with the 217-check suite, §13/§14 rewritten around T1B.5, dev commands corrected to the new layout with the Windows `php`/PATH caveat. (3) **README**: fixed the stale "129 backend acceptance checks" (actual 217) and removed a paragraph duplicated verbatim. Verified after changes: `php tests/run.php` → **217/217 PASS, exit 0**; `node tests/static-check.cjs` → **52/52 PASS, exit 0**. Still outstanding: T1B.5 (**test coverage, not code** — see §14), and §5 task IDs for the unlisted admin-panel / credentials / air-quality work.

- **2026-10-12 — Session 7 (T6.2, profile preferences):** Wired the profile screen's real controls — activity chips, preferred location, change password, delete account — replacing three `data-action="demo-only"` buttons that only toasted "not wired up yet". New `ProfileModel` + `ProfileController`, five routes, a `user_preferences` table and an idempotent migration. **Notifications were excluded by request and are disabled in the markup with the reason shown**, because nothing delivers them and a stored "daily summary: on" would be a promise the app cannot keep. Also closed the long-standing password-change session-invalidation gap with `users.password_changed_at`, which both the reset and profile paths now stamp. Three bugs were caught only by live HTTP testing (padded route keys, a missing result envelope, and the strength rule misapplied to the current password) — all fixed, each now covered by a test. 256 backend + 62 frontend checks pass.
- **2026-10-12 — Session 8 (preferred location drives the AQI):** Product-owner request — the saved location must always store real coordinates, show the city name with the coordinates in small type beneath it, and switching it must change the AQI. The instrument previously ignored the stored preference entirely, so it answered for the device position or the default city; that was a genuine behavioural gap, not just missing polish. Changes: `AirModel::pointFor()` extracted (explicit coord → saved location → default city), a third `saved` provenance string so a chosen place is never dressed up as the phone's position, server-side city resolution that ignores the client's `name`, 4dp coordinate rounding, a new `.settings-row__coords` style, and `airquality.js` gaining `usePreferredLocation()` so the device position stops being sent once a location is saved and the reading refreshes on save. Verified live: Johor Bahru 155 → Kuala Lumpur 76 → back to 155. 268 backend + 68 frontend checks pass.
- **2026-10-12 — Session 9 (profile location UX corrected):** The owner found Session 8's "Change" wrong: it re-ran device geolocation instead of searching for another city. Rebuilt — opening Profile now auto-detects and names the current city, and "Change" opens a debounced, keyboard-navigable city search. Added `PlacesModel`/`PlacesController` with `GET /api/places/search` and `GET /api/places/reverse`; forward geocoding required a new provider because BigDataCloud's keyless search path returns 403, so Photon is used for forward and BigDataCloud kept for reverse. Detection is now strictly read-only and returns early when a preference exists. Verified live against Photon and Open-Meteo: KL 77 → Kota Kinabalu 62 → Johor Bahru 153. Deleted the now-dead `saveLocationFromDevice()` rather than leaving it behind. 278 backend + 76 frontend checks pass.
- **2026-10-12 — Session 10 (relocate button):** Added the target-icon relocate control beside Change on the profile location row, per the owner's request. It detects the current position and saves it as the preference — the one action that could reach the previous design could not do, since entry-detection deliberately never saves and Change only searches. Round-trip verified live (JB 155 → KL 77 → JB 155). Guarded against double-fire and against the string/number mismatch in the geolocation denial code. 278 backend + 83 frontend checks pass.
- **2026-10-12 — Session 11 (two owner-reported bugs fixed):** (1) `Locating…`/`Searching…` rendered with junk glyphs — mojibake **I introduced earlier this session** via PowerShell `Get-Content -Raw` / `WriteAllText` round-trips on `app.js` and `ProfileModel.php`; the charset was always correct, and the files stayed valid UTF-8 so no test caught it. Repaired and now guarded by `tests/encoding-check.php`. (2) The location row stuck on "Locating…" after a refresh and relocate found nothing — caused by the template shipping "Locating…" as initial markup (any incomplete path stuck forever) and by two overlapping `getCurrentPosition` calls from the boot refresh and the profile's own detection. `locate()` now shares one in-flight promise and releases it on settle; `tests/locate-check.cjs` proves 3 concurrent callers cause exactly 1 request and that a denial still releases it. 278 backend + 88 static checks pass.
- **2026-10-12 — Session 12 (location model replaced; "auto reload shows Not set" fixed):** The owner restated the product rules and they are **not** what Session 9/10 built. There is now **one location, stored**: (1) every reload auto-detects and **saves** lat/lon and the card updates — (2) changing the location re-saves and the card follows — (3) signed in the card reads the saved row, signed out it reads the device position. Session 9's deliberate split (*detected* shown but never saved vs *preferred* driving the AQI) is gone, and `detectCurrentLocation()` was deleted rather than left behind.
  - **The reported bug ("auto reload, then it says Not set") was a boot-order defect, not the geolocation.** `render()` runs for the initial screen at script parse time, before `initSession()` resolves; `loadPreferences()` therefore returned on its first line with `currentUser` still null, and re-calling `render()` cannot help because it bails on `route === currentRoute`. The per-screen session work is now `onEnterScreen()`, called from both `render()` and the session boot.
  - `saveDeviceLocation()` detects, saves **coordinates only** (the server resolves the name, so no separate reverse-geocode round trip is needed), paints, and calls `usePreferredLocation(true)` on **every** exit path — including a refused fix and a failed save, where the card must still leave the device guess and go back to reading the row. It reports success as a boolean so the relocate button does not claim a city that did not change.
  - **One sync per page load**, held behind the `locationSync` promise, so the boot and a Profile entry share one detection and one save. The relocate button clears it first, because its whole point is that the answer changed since the page loaded.
  - **Rule 3 needed work at the session transitions**, which do not reload the page: `beginSession()` on mid-page sign-in (email, username and OTP — three call sites) and `usePreferredLocation(false)` on sign-out. Without these, a user who signed in or out without reloading kept the wrong card.
  - **A new race, found by reasoning through rule 1:** a signed-in load starts two air reads — the boot's device guess and the one against the row just written — and last-to-*finish* would have repainted the card, so a slow early request could leave the wrong city on screen. `refresh()` now takes a `++refreshSeq` ticket and abandons superseded calls before painting *and* before scheduling.
  - Honest wording: when nothing is saved, the failure note says readings fall back to the default city rather than claiming they "still use" a city that does not exist (`stillReading()`).
  - **Verified live over real HTTP** (throwaway `storage/smoke.ps1`, deleted afterwards): **15/15** — signed-in-with-nothing-saved → `default`; save JB → server-resolved name + reading `saved`; switch to KL → reading follows; JB and KL genuinely read differently; an explicit coordinate still answers `device`; signed out → `device` with a coordinate and `default` without; the row survives the session. Note for future live runs: **`Config::get()` gives `.env` priority over the process environment**, so `MAIL_DRIVER=log` must be set *in `.env`* — exporting it does nothing, and register() 502s on Brevo's IP allow-list. **278 backend + 93 static + 5 locate checks pass; `php -l` and `node --check` clean.**
- **2026-10-12 — follow-up (code read, not a test run).** Read `AuthModel`, `AuthController`, `Session`, `index.php` and the profile screen to confirm what T1B.5 actually requires. Findings: **(a)** all four T1B.5 criteria are already implemented — cookie flags `Session.php:24-30`, regeneration `:35-40`, CSRF enforced router-side `index.php:99-101`, `requireAuth()` 401 on `GET /api/auth/me`; **(b)** none of the four is asserted anywhere in `tests/run.php`, so T1B.5 is reclassified IN PROGRESS (evidence gap) rather than complete; **(c)** `password_changed_at` does not exist in the schema, confirming the reset-does-not-invalidate-sessions gap is real, not just undocumented; **(d)** the profile Change-password / Delete-account buttons are correctly labelled `demo-only` and fall through to an honest toast — **not a defect**, and they belong to T6.2, so they were removed from the T1B.5 scope rather than silently adopted.
- **2026-10-11 — Session 5:** Stage 1B built and verified. (1) Environment confirmed: XAMPP already installed (PHP 8.2.12, MariaDB 10.4.32, Apache, phpMyAdmin; all required PHP extensions present); Python 3.13.14 and Git 2.55.0 now available; user chose XAMPP as the dev runtime and deferred the email-provider decision (Brevo recommended; `log` driver used so development is unblocked). (2) T1A.11 **descoped** at the user's request — they will verify in the browser manually. (3) Delivered T1B.6 (schema + bootstrap + `.env.example` + `.gitignore`), T1B.1/T1B.2/T1B.3 (register+verify+resend, password login, email-OTP login), the Stage 1B foundation (T2.1/T2.2: front controller, Config, Db, Response, Request, Session, Csrf, RateLimiter, Mailer), and the frontend wiring (`frontend/js/api.js` + rewired `app.js`, all Stage 1A markup preserved). (4) Wrote `tests/run.php` — **52/52 checks pass** — plus HTTP smoke tests; static-check 25/25 pass; all PHP lints clean. (5) **Two real bugs found by testing and fixed:** `Db::future(-N)` emitted `+-N seconds`, which PHP parsed as a *positive* offset — this silently disabled **all** rate limiting (the window reset on every call); and `Session::login()` rotated the CSRF token without returning it, so the first state-changing request after login failed with 403. (6) Blocker recorded: a **pre-existing Aria corruption** in XAMPP's MariaDB prevents creating the least-privilege DB user; the app is unaffected (all tables InnoDB) and `.env` uses `root` for local dev only — a restart of XAMPP MySQL clears it.
